document.write("<link type=\"text/css\" rel=\"stylesheet\" href=\"sidebar/assets/style.css\"/>" +
		"<link type=\"text/css\" rel=\"stylesheet\" href=\"sidebar/assets/jScrollpanel.css\"/>" +
		"<script type=\"text/javascript\" src=\"sidebar/js/jquery-1.3.2.min.js\"></script>" +
		"<script type=\"text/javascript\" src=\"sidebar/js/jquery-ui-1.7.2.custom.min.js\"></script>" +
		"<script type=\"text/javascript\" src=\"sidebar/js/jquery.mousewheel.js\"></script>" +
		"<script type=\"text/javascript\" src=\"sidebar/js/jquery.em.js\"></script>" +
		"<script type=\"text/javascript\" src=\"sidebar/js/jScrollPane.js\"></script>" +
		"<script type=\"text/javascript\" src=\"sidebar/js/jquery.tooltip.min.js\"></script>" +
		"<script type=\"text/javascript\" src=\"sidebar/js/jquery.tooltip.pack.js\"></script>" +
		"<script type=\"text/javascript\" src=\"sidebar/js/side-bar.js\"></script>");