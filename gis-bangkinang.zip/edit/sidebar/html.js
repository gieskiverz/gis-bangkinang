//temp storage is used to convert html to text easily in javascript.
document.write("<div id=\"tempStorage\" style=\"display:none;\"></div>" +
		"<div id=\"sideBar\">" +
		"<a href=\"#\" id=\"sideBarTab\"><img src=\"sidebar/assets/spacer.gif\" alt=\"\" title=\"\"/></a>" +
		"<div id=\"sideBarContents\" style=\"display:none;\"><div id=\"sideBarContentsInner\">" +
			"<div id=\"scrollbar_container\">" +
				"<div id=\"scrollbar_content\">" +
				"</div>" +
				

			"</div></div></div></div>");

			