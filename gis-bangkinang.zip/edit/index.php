<?php
include'viewMap.php';
?>