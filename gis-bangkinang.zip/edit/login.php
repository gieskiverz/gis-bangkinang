<html>
	<head>
		<title>jejaring sosial - Welcome to jejaring sosial Community</title>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<link href="../css/login.css" type="text/css" rel="stylesheet" />
		
	</head>
	<style>
	
  </style>
	<body>
	<!-- background -->
		<div id="home-header">            
           <div style ="margin-left: auto; margin-right: auto;  height: 70px;">
		   
                <div align="left" style="margin-left: auto; margin-right: auto;  margin-top: 6px; width: 980px; color: #FFAA22;">
				
                                         <a href="http://bangkinang-maps.co.cc"  title="GIS"> 
										 <div id='font'>Sign In GIS Bangkinang </div></a>
										  <div id='error'></div>
						<!-- logo -->
                        <!-- <img src="login/logo.png" alt="jejaring sosial" style="float: left; border: 0px;"  /> -->
                   
                                        <div id="header_login" style="float: right; width: 350px; ">
      
                        
                    </div>
                </div>
            </div>
			<div class="homepage_maindiv">
    <div align="left" class="homepage_innerdiv">
        <div class="intro-text">
            <h1 style="text-shadow: white 0 em 0 em 0 em; "><center>Geographic Information System</center> </h1>
			<br>Google Maps adalah sebuah jasa peta globe virtual gratis dan online disediakan oleh Google dapat ditemukan di 
			<a href="http://maps.google.com" target="_blank">http://maps.google.com </a>. 
			Google menawarkan peta yang dapat diseret dan gambar satelit untuk seluruh dunia dan baru-baru ini, Bulan, dan juga menawarkan perencana rute dan pencari letak bisnis di U.S., Kanada, Jepang, Hong Kong, Cina, UK, Irlandia (hanya pusat kota) dan beberapa bagian Eropa <a href="http://maps.google.com" target="_blank">(http://id.wikipedia.org/wiki/Google_Maps) </a>.      </div>
        <div id="registration" style="">
            <form method="post" action="../loginsubmit.php">
                <div style="margin: 0px 0px 5px 5px;">Sign account</div>
                                <input id="Username" placeholder="Username:" name="Username" size="20"  type="text" />
								<input id="Password" placeholder="Password:" name="Password" size="20"  type="password" />
                                <br><br><br>
                <input class="homepage_signup" style="border: 0px; width: 256px; height: 33px; border: 1px solid #FFAA22;" type="submit" value="Sign In">
            </form>
                    </div>
      
    </div>
</div>

</div>

<div class="golden_line"></div>
                <div align="left" style="margin-left: auto; margin-right: auto; width: 980px; background-image: none;">
						
			<div id="subfooter">
				<div id="sfleft">
					<b><a href="http://bangkinag-maps.co.cc">Sistem Informasi Geografis Fasilitas Umum Kota Bangkinang</a></b>
					
					
									</div>
				<div id="sfright">
					<span style="color:#888;">
					
														Powered by <a href="http://syarif25.tk" target="_blank"> <!-- &middot; --> deyen 2012</a>
													<!-- "Powered by Sharetronix" backlink END -->
							
					</span> 
				</div>
			</div>
		</div>
		
				
	</body>
</html>