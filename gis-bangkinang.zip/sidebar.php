<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>script.aculo.us sidebar</title>

<script type="text/javascript" src="js/prototype.js"></script>
<script type="text/javascript" src="js/effects.js"></script>
<script type="text/javascript" src="js/side-bar.js"></script>

<style>


/****************************************/

a{
	outline: none;
}

a:active{
	outline: none;
}

#sideBar{
text-align:left;
}

#sideBar h2{
	color:#FFFFFF;
	font-size:110%;
	font-family:arial;
	margin:10px 10px 10px 10px;
	font-weight:bold !important;
}

#sideBar h2 span{
	font-size:125%;
	font-weight:normal !important;
}

#sideBar ul{
	margin:0px 0px 0px 0px;
	padding:0px 0px 0px 0px;
}

#sideBar li{
	margin:0px 10px 3px 10px;
	padding:2px;
	list-style-type:none;
	display:block;
	background-color:#DA1074;
	width:177px;
	color:#FFFFFF;
}

#sideBar li a{
	width:100%;
}

#sideBar li a:link,
#sideBar li a:visited{
	color:#FFFFFF;
	font-family:verdana;
	font-size:100%;
	text-decoration:none;
	display:block;
	margin:0px 0px 0px 0px;
	padding:0px;
	width:100%;
}

#sideBar li a:hover{
	color:#FFFFFF;
	text-decoration:underline;
}

#sideBar{
	position: absolute;
	width: auto;
	height: auto;
	top: 140px;
	right:0px;
	background-image:url(images/background.gif);
	background-position:top left;
	background-repeat:repeat-y;
}

#sideBarTab{
	float:left;
	height:137px;
	width:28px;
}

#sideBarTab img{
	border:0px solid #FFFFFF;
}

#sideBarContents{
	float:left;
	overflow:hidden !important;
	width:200px;
	height:320px;
}

#sideBarContentsInner{
	width:200px;
}
</style>


</head>

<body>

<div id="sideBar">
	
	<a href="#" id="sideBarTab"><img src="images/slide-button.gif" alt="sideBar" title="sideBar" /></a>
	
	<div id="sideBarContents" style="display:none;">
		<div id="sideBarContentsInner">
			<h2>side<span>bar</span></h2>
			
			<ul>
				<li><a href="#">Link One</a></li>
				<li><a href="#">Link Two</a></li>
				<li><a href="#">Link Three</a></li>
				<li><a href="#">Link Four</a></li>
				<li><a href="#">Link Five</a></li>
			</ul>
			
		</div>
	</div>
	
</div>

</body>
</html>