<?php
$server = 'localhost';
$user = 'root';
$password = 'rita';
$db = 'test';

$url_folder_gambar = 'http://localhost/gis-bangkinang/galeri/upload/';
?>